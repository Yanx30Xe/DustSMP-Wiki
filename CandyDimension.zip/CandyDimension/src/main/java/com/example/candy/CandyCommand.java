package com.example.candy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class CandyCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUB = List.of("give", "tp", "exit", "reload");
    private static final List<String> ITEMS = List.of("shard", "disc", "sword", "axe", "pickaxe");

    private final CandyPlugin plugin;

    public CandyCommand(CandyPlugin plugin) {
        this.plugin = plugin;
    }

    private void say(CommandSender s, String msg, NamedTextColor color) {
        s.sendMessage(Component.text(msg, color));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            say(sender, "Pakai: /candy give <shard|disc|sword|axe|pickaxe> [jumlah] [pemain] | tp | exit | reload", NamedTextColor.YELLOW);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "give" -> give(sender, args);
            case "tp" -> {
                if (!(sender instanceof Player p)) {
                    say(sender, "Hanya untuk pemain.", NamedTextColor.RED);
                    return true;
                }
                if (plugin.candyWorld().world() == null) {
                    say(sender, "Candy Dimension tidak termuat.", NamedTextColor.RED);
                    return true;
                }
                if (!plugin.candyWorld().isCandy(p.getWorld())) {
                    plugin.returns().set(p.getUniqueId(), p.getLocation());
                }
                p.teleport(plugin.candyWorld().arrival());
            }
            case "exit" -> {
                if (!(sender instanceof Player p)) {
                    say(sender, "Hanya untuk pemain.", NamedTextColor.RED);
                    return true;
                }
                plugin.exitPortals().sendBack(p);
            }
            case "reload" -> {
                plugin.reloadConfig();
                say(sender, "Config dimuat ulang. (Seed/nama world butuh restart.)", NamedTextColor.GREEN);
            }
            default -> say(sender, "Subcommand tidak dikenal.", NamedTextColor.RED);
        }
        return true;
    }

    private void give(CommandSender sender, String[] args) {
        if (args.length < 2) {
            say(sender, "Pakai: /candy give <shard|disc|sword|axe|pickaxe> [jumlah] [pemain]", NamedTextColor.YELLOW);
            return;
        }
        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Math.max(1, Math.min(64, Integer.parseInt(args[2])));
            } catch (NumberFormatException ex) {
                say(sender, "Jumlah harus angka.", NamedTextColor.RED);
                return;
            }
        }
        Player target;
        if (args.length >= 4) {
            target = Bukkit.getPlayerExact(args[3]);
        } else {
            target = sender instanceof Player p ? p : null;
        }
        if (target == null) {
            say(sender, "Pemain tidak ditemukan.", NamedTextColor.RED);
            return;
        }
        ItemStack stack = plugin.items().byName(args[1], amount);
        if (stack == null) {
            say(sender, "Item tidak dikenal.", NamedTextColor.RED);
            return;
        }
        Map<Integer, ItemStack> left = target.getInventory().addItem(stack);
        for (ItemStack rest : left.values()) {
            Location l = target.getLocation();
            l.getWorld().dropItemNaturally(l, rest);
        }
        say(sender, "Diberikan ke " + target.getName() + ".", NamedTextColor.GREEN);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : SUB) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    out.add(s);
                }
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (String s : ITEMS) {
                if (s.startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    out.add(s);
                }
            }
        }
        return out;
    }
}
