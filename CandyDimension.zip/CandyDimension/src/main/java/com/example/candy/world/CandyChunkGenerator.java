package com.example.candy.world;

import org.bukkit.Axis;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Biome;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Orientable;
import org.bukkit.generator.BiomeProvider;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;

import java.util.List;
import java.util.Random;

public final class CandyChunkGenerator extends ChunkGenerator {

    private final CandyTerrain terrain;
    private final CandyPopulator populator;
    private final BlockData topLog;

    public CandyChunkGenerator(long seed) {
        this.terrain = new CandyTerrain(seed);
        this.populator = new CandyPopulator(seed, terrain);
        // Stripped cherry log lying on its side, so the pink side texture faces up.
        Orientable log = (Orientable) Bukkit.createBlockData(Material.STRIPPED_CHERRY_LOG);
        log.setAxis(Axis.X);
        this.topLog = log;
    }

    @Override
    public void generateNoise(WorldInfo worldInfo, Random random, int chunkX, int chunkZ, ChunkData data) {
        int minY = worldInfo.getMinHeight();
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int h = terrain.height(chunkX * 16 + x, chunkZ * 16 + z);
                data.setBlock(x, minY, z, Material.BEDROCK);
                data.setRegion(x, minY + 1, z, x + 1, h - 4, z + 1, Material.PINK_TERRACOTTA);
                data.setRegion(x, h - 4, z, x + 1, h - 1, z + 1, Material.PINK_CONCRETE);
                data.setBlock(x, h - 1, z, topLog);
            }
        }
    }

    @Override
    public List<BlockPopulator> getDefaultPopulators(World world) {
        return List.of(populator);
    }

    @Override
    public BiomeProvider getDefaultBiomeProvider(WorldInfo worldInfo) {
        return new BiomeProvider() {
            @Override
            public Biome getBiome(WorldInfo info, int x, int y, int z) {
                return Biome.CHERRY_GROVE;
            }

            @Override
            public List<Biome> getBiomes(WorldInfo info) {
                return List.of(Biome.CHERRY_GROVE);
            }
        };
    }

    @Override
    public Location getFixedSpawnLocation(World world, Random random) {
        return new Location(world, 0.5, terrain.height(0, 0), 0.5);
    }

    @Override
    public boolean canSpawn(World world, int x, int z) {
        return true;
    }
}
