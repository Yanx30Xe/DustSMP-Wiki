package com.example.candy;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.RayTraceResult;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Candy Pickaxe: breaks a 3x3 area. */
public final class ItemListener implements Listener {

    private final CandyPlugin plugin;
    private final Set<UUID> busy = new HashSet<>();

    public ItemListener(CandyPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.HIGH)
    public void onBreak(BlockBreakEvent e) {
        if (!plugin.getConfig().getBoolean("pickaxe.area-3x3", true)) {
            return;
        }
        Player p = e.getPlayer();
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (!plugin.items().is(tool, CandyItems.PICKAXE)) {
            return;
        }
        if (p.isSneaking()) {
            return;
        }
        if (!busy.add(p.getUniqueId())) {
            return;
        }
        try {
            Block center = e.getBlock();
            BlockFace face = faceOf(p, center);
            for (Block b : around(center, face)) {
                if (breakable(b)) {
                    p.breakBlock(b);
                }
            }
        } finally {
            busy.remove(p.getUniqueId());
        }
    }

    private BlockFace faceOf(Player p, Block center) {
        RayTraceResult r = p.rayTraceBlocks(6.0);
        if (r != null && r.getHitBlockFace() != null && center.equals(r.getHitBlock())) {
            return r.getHitBlockFace();
        }
        float pitch = p.getLocation().getPitch();
        if (pitch > 55) {
            return BlockFace.UP;
        }
        if (pitch < -55) {
            return BlockFace.DOWN;
        }
        return p.getFacing().getOppositeFace();
    }

    private List<Block> around(Block center, BlockFace face) {
        int fx = Math.abs(face.getModX());
        int fy = Math.abs(face.getModY());
        List<Block> out = new ArrayList<>();
        for (int a = -1; a <= 1; a++) {
            for (int c = -1; c <= 1; c++) {
                if (a == 0 && c == 0) {
                    continue;
                }
                int dx;
                int dy;
                int dz;
                if (fy == 1) {
                    dx = a;
                    dy = 0;
                    dz = c;
                } else if (fx == 1) {
                    dx = 0;
                    dy = a;
                    dz = c;
                } else {
                    dx = a;
                    dy = c;
                    dz = 0;
                }
                out.add(center.getRelative(dx, dy, dz));
            }
        }
        return out;
    }

    private boolean breakable(Block b) {
        Material m = b.getType();
        if (m.isAir() || b.isLiquid()) {
            return false;
        }
        float hardness = m.getHardness();
        if (hardness < 0 || hardness > 25) {
            return false;
        }
        if (m == Material.SPAWNER) {
            return false;
        }
        return !(b.getState() instanceof Container);
    }
}
