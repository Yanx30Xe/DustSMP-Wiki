package com.example.candy;

import com.example.candy.world.CandyChunkGenerator;
import com.example.candy.world.CandyTerrain;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.scheduler.BukkitRunnable;

public final class CandyWorld {

    public static final String DEFAULT_NAME = "candy_dimension";

    private final CandyPlugin plugin;
    private World world;
    private CandyTerrain terrain;
    private long seed;

    public CandyWorld(CandyPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        seed = plugin.getConfig().getLong("candy-world.seed", 20260607L);
        String name = plugin.getConfig().getString("candy-world.name", DEFAULT_NAME);
        terrain = new CandyTerrain(seed);

        WorldCreator creator = new WorldCreator(name);
        creator.seed(seed);
        creator.environment(World.Environment.NORMAL);
        creator.generator(new CandyChunkGenerator(seed));
        creator.generateStructures(false);
        world = Bukkit.createWorld(creator);

        if (world == null) {
            plugin.getLogger().severe("Could not create the Candy Dimension world!");
            return;
        }

        world.setSpawnLocation(0, terrain.height(0, 0), 0);
        world.setDifficulty(Bukkit.getWorlds().get(0).getDifficulty());
        world.setStorm(false);
        world.setThundering(false);
        world.setTime(6000L);

        new BukkitRunnable() {
            @Override
            public void run() {
                if (world != null && world.hasStorm()) {
                    world.setStorm(false);
                }
            }
        }.runTaskTimer(plugin, 200L, 200L);
    }

    public World world() {
        return world;
    }

    public CandyTerrain terrain() {
        return terrain;
    }

    public long seed() {
        return seed;
    }

    public boolean isCandy(World other) {
        return world != null && other != null && other.getUID().equals(world.getUID());
    }

    public Location arrival() {
        return new Location(world, 0.5, terrain.height(0, 0), 0.5, 0f, 0f);
    }
}
