package com.example.candy;

import io.papermc.paper.datacomponent.DataComponentTypes;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public final class CandyItems {

    public static final String SHARD = "shard";
    public static final String DISC = "disc";
    public static final String SWORD = "sword";
    public static final String AXE = "axe";
    public static final String PICKAXE = "pickaxe";

    private final NamespacedKey typeKey;

    public CandyItems(JavaPlugin plugin) {
        this.typeKey = new NamespacedKey(plugin, "candy_item");
    }

    private ItemStack build(Material material, String type, String name, NamedTextColor color, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(name, color).decoration(TextDecoration.ITALIC, false));
        List<Component> lines = new ArrayList<>();
        for (String line : lore) {
            lines.add(Component.text(line, NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lines);
        meta.getPersistentDataContainer().set(typeKey, PersistentDataType.STRING, type);
        meta.setEnchantmentGlintOverride(true);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack enchant(ItemStack item, Object... pairs) {
        ItemMeta meta = item.getItemMeta();
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            meta.addEnchant((Enchantment) pairs[i], (Integer) pairs[i + 1], true);
        }
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack shard(int amount) {
        ItemStack item = build(Material.PRISMARINE_SHARD, SHARD, "Candy Shard", NamedTextColor.LIGHT_PURPLE,
                "Pecahan permen yang langka.", "Bahan untuk membuat Candy Disc.");
        item.setAmount(Math.max(1, amount));
        return item;
    }

    public ItemStack disc() {
        ItemStack item = build(Material.MUSIC_DISC_PIGSTEP, DISC, "Candy Disc", NamedTextColor.LIGHT_PURPLE,
                "Tidak ada lagu di dalamnya...", "Masukkan ke jukebox dekat portal Deep Dark.");
        // Remove the vanilla song so it cannot be played in a jukebox.
        item.unsetData(DataComponentTypes.JUKEBOX_PLAYABLE);
        return item;
    }

    public ItemStack sword() {
        ItemStack item = build(Material.NETHERITE_SWORD, SWORD, "Candy Sword", NamedTextColor.LIGHT_PURPLE,
                "Pedang manis dari Candy Dimension.");
        return enchant(item,
                Enchantment.SHARPNESS, 5,
                Enchantment.SMITE, 5,
                Enchantment.SWEEPING_EDGE, 3,
                Enchantment.KNOCKBACK, 1,
                Enchantment.FIRE_ASPECT, 2,
                Enchantment.UNBREAKING, 3,
                Enchantment.MENDING, 1);
    }

    public ItemStack axe() {
        ItemStack item = build(Material.NETHERITE_AXE, AXE, "Candy Axe", NamedTextColor.LIGHT_PURPLE,
                "Kapak manis dari Candy Dimension.");
        return enchant(item,
                Enchantment.SHARPNESS, 6,
                Enchantment.SMITE, 5,
                Enchantment.EFFICIENCY, 5,
                Enchantment.FIRE_ASPECT, 2,
                Enchantment.UNBREAKING, 3,
                Enchantment.MENDING, 1);
    }

    public ItemStack pickaxe() {
        ItemStack item = build(Material.NETHERITE_PICKAXE, PICKAXE, "Candy Pickaxe", NamedTextColor.LIGHT_PURPLE,
                "Menghancurkan area 3x3.", "Tahan sneak untuk 1 blok saja.");
        return enchant(item,
                Enchantment.EFFICIENCY, 6,
                Enchantment.FORTUNE, 4,
                Enchantment.UNBREAKING, 3,
                Enchantment.MENDING, 1);
    }

    public ItemStack byName(String name, int amount) {
        switch (name.toLowerCase()) {
            case SHARD:
                return shard(amount);
            case DISC: {
                ItemStack d = disc();
                d.setAmount(Math.max(1, Math.min(64, amount)));
                return d;
            }
            case SWORD:
                return sword();
            case AXE:
                return axe();
            case PICKAXE:
                return pickaxe();
            default:
                return null;
        }
    }

    public String typeOf(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return null;
        }
        return stack.getItemMeta().getPersistentDataContainer().get(typeKey, PersistentDataType.STRING);
    }

    public boolean is(ItemStack stack, String type) {
        return type.equals(typeOf(stack));
    }
}
