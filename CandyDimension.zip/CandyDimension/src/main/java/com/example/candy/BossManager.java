package com.example.candy;

import com.example.candy.world.CandyPopulator;
import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Warden;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** Candy Boss: a buffed Warden that lives in the arenas of the Candy Dimension. */
public final class BossManager implements Listener {

    private final CandyPlugin plugin;
    private final NamespacedKey bossKey;
    private final NamespacedKey doneKey;
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final Random random = new Random();
    private BukkitRunnable task;

    public BossManager(CandyPlugin plugin) {
        this.plugin = plugin;
        this.bossKey = new NamespacedKey(plugin, "candy_boss");
        this.doneKey = new NamespacedKey(plugin, "boss_done");
    }

    public boolean isBoss(Entity e) {
        return e.getPersistentDataContainer().has(bossKey, PersistentDataType.BYTE);
    }

    public void start() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                updateBars();
            }
        };
        task.runTaskTimer(plugin, 40L, 10L);
    }

    public void shutdown() {
        World w = plugin.candyWorld().world();
        for (BossBar bar : bars.values()) {
            if (w != null) {
                for (Player p : w.getPlayers()) {
                    p.hideBossBar(bar);
                }
            }
        }
        bars.clear();
    }

    // ------------------------------------------------------------------ spawning

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent e) {
        World cw = plugin.candyWorld().world();
        if (cw == null || !e.getWorld().equals(cw)) {
            return;
        }
        Chunk c = e.getChunk();
        if (!CandyPopulator.isBossChunk(plugin.candyWorld().seed(), c.getX(), c.getZ())) {
            return;
        }
        if (c.getPersistentDataContainer().has(doneKey, PersistentDataType.BYTE)) {
            return;
        }
        attempt(c.getX(), c.getZ(), 0);
    }

    private void attempt(int cx, int cz, int tries) {
        World w = plugin.candyWorld().world();
        if (w == null) {
            return;
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!w.isChunkLoaded(cx, cz)) {
                return;
            }
            Chunk chunk = w.getChunkAt(cx, cz);
            if (chunk.getPersistentDataContainer().has(doneKey, PersistentDataType.BYTE)) {
                return;
            }
            int x = cx * 16 + 8;
            int z = cz * 16 + 8;
            int fy = plugin.candyWorld().terrain().height(x, z) - 1;
            if (w.getBlockAt(x, fy, z).getType() != Material.CRYING_OBSIDIAN) {
                if (tries < 8) {
                    attempt(cx, cz, tries + 1);
                }
                return;
            }
            chunk.getPersistentDataContainer().set(doneKey, PersistentDataType.BYTE, (byte) 1);
            spawnBoss(new Location(w, x + 0.5, fy + 1, z + 0.5));
        }, 40L);
    }

    public Warden spawnBoss(Location loc) {
        double health = plugin.getConfig().getDouble("boss.health", 800.0);
        return loc.getWorld().spawn(loc, Warden.class, w -> {
            w.customName(Component.text("Candy Boss", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD));
            w.setCustomNameVisible(true);
            w.setPersistent(true);
            w.setRemoveWhenFarAway(false);
            w.getPersistentDataContainer().set(bossKey, PersistentDataType.BYTE, (byte) 1);
            AttributeInstance hp = w.getAttribute(Attribute.MAX_HEALTH);
            if (hp != null) {
                hp.setBaseValue(health);
                w.setHealth(health);
            }
        });
    }

    // ------------------------------------------------------------------ boss bars

    private void updateBars() {
        World w = plugin.candyWorld().world();
        if (w == null) {
            return;
        }
        Set<UUID> seen = new HashSet<>();
        for (Warden boss : w.getEntitiesByClass(Warden.class)) {
            if (!isBoss(boss) || boss.isDead()) {
                continue;
            }
            seen.add(boss.getUniqueId());
            BossBar bar = bars.get(boss.getUniqueId());
            if (bar == null) {
                bar = BossBar.bossBar(
                        Component.text("Candy Boss", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD),
                        1f, BossBar.Color.PINK, BossBar.Overlay.NOTCHED_10);
                bars.put(boss.getUniqueId(), bar);
            }
            AttributeInstance hp = boss.getAttribute(Attribute.MAX_HEALTH);
            double max = hp == null ? 500.0 : hp.getValue();
            bar.progress((float) Math.max(0.0, Math.min(1.0, boss.getHealth() / max)));
            for (Player p : w.getPlayers()) {
                if (p.getLocation().distanceSquared(boss.getLocation()) <= 64.0 * 64.0) {
                    p.showBossBar(bar);
                } else {
                    p.hideBossBar(bar);
                }
            }
        }
        Set<UUID> stale = new HashSet<>(bars.keySet());
        stale.removeAll(seen);
        for (UUID id : stale) {
            BossBar bar = bars.remove(id);
            for (Player p : w.getPlayers()) {
                p.hideBossBar(bar);
            }
        }
    }

    // ------------------------------------------------------------------ loot

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        LivingEntity ent = e.getEntity();
        if (!isBoss(ent)) {
            return;
        }
        BossBar bar = bars.remove(ent.getUniqueId());
        if (bar != null) {
            for (Player p : ent.getWorld().getPlayers()) {
                p.hideBossBar(bar);
            }
        }
        e.getDrops().clear();
        e.getDrops().add(rollLoot());
        e.setDroppedExp(2000);

        Player killer = ent.getKiller();
        String who = killer == null ? "seseorang" : killer.getName();
        for (Player p : ent.getWorld().getPlayers()) {
            p.sendMessage(Component.text("✦ Candy Boss telah dikalahkan oleh " + who + "!", NamedTextColor.LIGHT_PURPLE));
        }
    }

    private ItemStack rollLoot() {
        int shard = plugin.getConfig().getInt("boss.loot-weights.shard", 40);
        int disc = plugin.getConfig().getInt("boss.loot-weights.disc", 20);
        int sword = plugin.getConfig().getInt("boss.loot-weights.sword", 14);
        int axe = plugin.getConfig().getInt("boss.loot-weights.axe", 13);
        int pick = plugin.getConfig().getInt("boss.loot-weights.pickaxe", 13);
        int total = shard + disc + sword + axe + pick;
        int roll = random.nextInt(Math.max(1, total));

        CandyItems items = plugin.items();
        if (roll < shard) {
            int min = plugin.getConfig().getInt("boss.shard-amount-min", 8);
            int max = Math.max(min, plugin.getConfig().getInt("boss.shard-amount-max", 16));
            return items.shard(min + random.nextInt(max - min + 1));
        }
        roll -= shard;
        if (roll < disc) {
            return items.disc();
        }
        roll -= disc;
        if (roll < sword) {
            return items.sword();
        }
        roll -= sword;
        if (roll < axe) {
            return items.axe();
        }
        return items.pickaxe();
    }
}
