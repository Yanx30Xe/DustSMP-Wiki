package com.example.candy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Color;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.type.GlassPane;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;

/** Ancient City portal: jukebox + Candy Disc -> cutscene -> pink glass portal -> Candy Dimension. */
public final class PortalManager implements Listener {

    private static final int PANES_START = 30;
    private static final int PANES_END = 120;
    private static final int SHAKE_START = 130;
    private static final int EXPLODE_TICK = 200;
    private static final int END_TICK = 225;

    private record Pos(int x, int y, int z) {
    }

    private static final class ActivePortal {
        final String key;
        final World world;
        final List<Block> interior;
        final Vector center;
        final boolean planeX;
        final BoundingBox trigger;
        boolean open;
        long closeAt;
        BukkitRunnable closer;

        ActivePortal(String key, World world, List<Block> interior, Vector center, boolean planeX, BoundingBox trigger) {
            this.key = key;
            this.world = world;
            this.interior = interior;
            this.center = center;
            this.planeX = planeX;
            this.trigger = trigger;
        }
    }

    private static final class Result {
        final ActivePortal portal;
        final String error;

        Result(ActivePortal portal, String error) {
            this.portal = portal;
            this.error = error;
        }
    }

    private final CandyPlugin plugin;
    private final Map<String, ActivePortal> portals = new HashMap<>();
    private final Map<UUID, Cutscene> cutscenes = new HashMap<>();
    private BukkitRunnable contactTask;

    public PortalManager(CandyPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        contactTask = new BukkitRunnable() {
            @Override
            public void run() {
                checkContacts();
            }
        };
        contactTask.runTaskTimer(plugin, 20L, 3L);
    }

    public void shutdown() {
        for (Cutscene c : new ArrayList<>(cutscenes.values())) {
            c.finish(false);
        }
        for (ActivePortal ap : new ArrayList<>(portals.values())) {
            closePortal(ap);
        }
    }

    // ------------------------------------------------------------------ events

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Block clicked = e.getClickedBlock();
        if (clicked == null || clicked.getType() != Material.JUKEBOX) {
            return;
        }
        ItemStack inHand = e.getItem();
        if (!plugin.items().is(inHand, CandyItems.DISC)) {
            return;
        }
        e.setCancelled(true);
        tryActivate(e.getPlayer(), clicked);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Cutscene c = cutscenes.get(e.getPlayer().getUniqueId());
        if (c != null) {
            c.finish(false);
        }
    }

    // ------------------------------------------------------------------ activation

    private void tryActivate(Player p, Block jukebox) {
        World world = jukebox.getWorld();
        if (plugin.candyWorld().isCandy(world) || world.getEnvironment() != World.Environment.NORMAL) {
            p.sendMessage(Component.text("Portal ini hanya bisa dibuka di Overworld.", NamedTextColor.RED));
            return;
        }
        if (cutscenes.containsKey(p.getUniqueId())) {
            return;
        }
        if (plugin.candyWorld().world() == null) {
            p.sendMessage(Component.text("Candy Dimension gagal dimuat. Hubungi admin.", NamedTextColor.RED));
            return;
        }

        Result res = findPortal(jukebox);
        if (res.portal == null) {
            p.sendMessage(Component.text(res.error, NamedTextColor.RED));
            return;
        }
        if (portals.containsKey(res.portal.key)) {
            p.sendMessage(Component.text("Portal ini sedang aktif.", NamedTextColor.RED));
            return;
        }

        if (plugin.getConfig().getBoolean("portal.consume-disc", true)) {
            ItemStack hand = p.getInventory().getItemInMainHand();
            hand.setAmount(hand.getAmount() - 1);
        }

        portals.put(res.portal.key, res.portal);

        Location jl = jukebox.getLocation().add(0.5, 1.2, 0.5);
        world.spawnParticle(Particle.NOTE, jl, 12, 0.4, 0.3, 0.4, 1.0);
        world.playSound(jl, Sound.BLOCK_NOTE_BLOCK_CHIME, 2f, 1.4f);

        Cutscene scene = new Cutscene(p, res.portal);
        cutscenes.put(p.getUniqueId(), scene);
        scene.runTaskTimer(plugin, 1L, 1L);
    }

    // ------------------------------------------------------------------ finding the Ancient City portal

    private Result findPortal(Block jukebox) {
        World world = jukebox.getWorld();
        Material frame = Material.matchMaterial(plugin.getConfig().getString("portal.frame-block", "REINFORCED_DEEPSLATE"));
        if (frame == null) {
            frame = Material.REINFORCED_DEEPSLATE;
        }
        int radius = plugin.getConfig().getInt("portal.radius", 30);
        int jx = jukebox.getX();
        int jy = jukebox.getY();
        int jz = jukebox.getZ();
        int minH = world.getMinHeight();
        int maxH = world.getMaxHeight();

        Pos nearest = null;
        double best = Double.MAX_VALUE;
        for (int x = jx - radius; x <= jx + radius; x++) {
            for (int z = jz - radius; z <= jz + radius; z++) {
                if (!world.isChunkLoaded(x >> 4, z >> 4)) {
                    continue;
                }
                for (int y = Math.max(minH, jy - radius); y <= Math.min(maxH - 1, jy + radius); y++) {
                    if (world.getType(x, y, z) != frame) {
                        continue;
                    }
                    double d = (double) (x - jx) * (x - jx) + (double) (y - jy) * (y - jy) + (double) (z - jz) * (z - jz);
                    if (d <= (double) radius * radius && d < best) {
                        best = d;
                        nearest = new Pos(x, y, z);
                    }
                }
            }
        }
        if (nearest == null) {
            return new Result(null, "Tidak ada portal Deep Dark dalam radius " + radius + " blok dari jukebox ini.");
        }

        // flood fill the frame
        Set<Pos> frameSet = new HashSet<>();
        ArrayDeque<Pos> queue = new ArrayDeque<>();
        frameSet.add(nearest);
        queue.add(nearest);
        while (!queue.isEmpty() && frameSet.size() < 800) {
            Pos p = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) {
                            continue;
                        }
                        Pos n = new Pos(p.x() + dx, p.y() + dy, p.z() + dz);
                        if (frameSet.contains(n)) {
                            continue;
                        }
                        if (Math.abs(n.x() - nearest.x()) > 30 || Math.abs(n.y() - nearest.y()) > 30
                                || Math.abs(n.z() - nearest.z()) > 30) {
                            continue;
                        }
                        if (!world.isChunkLoaded(n.x() >> 4, n.z() >> 4)) {
                            continue;
                        }
                        if (world.getType(n.x(), n.y(), n.z()) == frame) {
                            frameSet.add(n);
                            queue.add(n);
                        }
                    }
                }
            }
        }
        if (frameSet.size() < 8) {
            return new Result(null, "Bingkai portal terlalu kecil atau tidak lengkap.");
        }

        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (Pos p : frameSet) {
            minX = Math.min(minX, p.x());
            minY = Math.min(minY, p.y());
            minZ = Math.min(minZ, p.z());
            maxX = Math.max(maxX, p.x());
            maxY = Math.max(maxY, p.y());
            maxZ = Math.max(maxZ, p.z());
        }
        int ex = maxX - minX;
        int ez = maxZ - minZ;
        if (Math.min(ex, ez) > 2) {
            return new Result(null, "Bentuk bingkai tidak terbaca sebagai portal yang berdiri tegak.");
        }
        boolean planeX = ex <= ez;
        int width = planeX ? ez - 1 : ex - 1;
        int height = maxY - minY - 1;
        if (width < 1 || height < 1) {
            return new Result(null, "Bingkai portal tidak punya ruang kosong di dalamnya.");
        }
        if (width > 24 || height > 24) {
            return new Result(null, "Bingkai portal terlalu besar.");
        }

        List<Block> interior = new ArrayList<>();
        if (planeX) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ + 1; z <= maxZ - 1; z++) {
                    for (int y = minY + 1; y <= maxY - 1; y++) {
                        consider(world, frameSet, interior, x, y, z);
                    }
                }
            }
        } else {
            for (int z = minZ; z <= maxZ; z++) {
                for (int x = minX + 1; x <= maxX - 1; x++) {
                    for (int y = minY + 1; y <= maxY - 1; y++) {
                        consider(world, frameSet, interior, x, y, z);
                    }
                }
            }
        }
        if (interior.isEmpty()) {
            return new Result(null, "Bagian dalam bingkai portal terhalang.");
        }

        double sx = 0, sy = 0, sz = 0;
        int ix0 = Integer.MAX_VALUE, iy0 = Integer.MAX_VALUE, iz0 = Integer.MAX_VALUE;
        int ix1 = Integer.MIN_VALUE, iy1 = Integer.MIN_VALUE, iz1 = Integer.MIN_VALUE;
        for (Block b : interior) {
            sx += b.getX() + 0.5;
            sy += b.getY() + 0.5;
            sz += b.getZ() + 0.5;
            ix0 = Math.min(ix0, b.getX());
            iy0 = Math.min(iy0, b.getY());
            iz0 = Math.min(iz0, b.getZ());
            ix1 = Math.max(ix1, b.getX());
            iy1 = Math.max(iy1, b.getY());
            iz1 = Math.max(iz1, b.getZ());
        }
        int n = interior.size();
        Vector center = new Vector(sx / n, sy / n, sz / n);
        BoundingBox trigger = new BoundingBox(ix0, iy0, iz0, ix1 + 1, iy1 + 1, iz1 + 1);
        if (planeX) {
            trigger.expand(0.65, 0.0, 0.0);
        } else {
            trigger.expand(0.0, 0.0, 0.65);
        }
        String key = world.getUID() + ":" + minX + "," + minY + "," + minZ;
        return new Result(new ActivePortal(key, world, interior, center, planeX, trigger), null);
    }

    private void consider(World world, Set<Pos> frameSet, List<Block> out, int x, int y, int z) {
        if (frameSet.contains(new Pos(x, y, z))) {
            return;
        }
        Block b = world.getBlockAt(x, y, z);
        if (b.getType().isAir() || b.isReplaceable()) {
            out.add(b);
        }
    }

    // ------------------------------------------------------------------ panes

    private GlassPane paneData(boolean planeX) {
        GlassPane gp = (GlassPane) Material.PINK_STAINED_GLASS_PANE.createBlockData();
        if (planeX) {
            gp.setFace(BlockFace.NORTH, true);
            gp.setFace(BlockFace.SOUTH, true);
        } else {
            gp.setFace(BlockFace.EAST, true);
            gp.setFace(BlockFace.WEST, true);
        }
        return gp;
    }

    private void placeRow(ActivePortal ap, List<Block> row, int index) {
        GlassPane data = paneData(ap.planeX);
        Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB(255, 120, 190), 1.6f);
        for (Block b : row) {
            b.setBlockData(data, false);
            Location l = b.getLocation().add(0.5, 0.5, 0.5);
            ap.world.spawnParticle(Particle.DUST, l, 6, 0.3, 0.3, 0.3, 0.0, dust);
        }
        Location c = ap.center.toLocation(ap.world);
        float pitch = (float) Math.min(2.0, 0.6 + index * 0.1);
        ap.world.playSound(c, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 2f, pitch);
    }

    // ------------------------------------------------------------------ open / close

    private void openPortal(ActivePortal ap) {
        int seconds = plugin.getConfig().getInt("portal.open-seconds", 30);
        ap.open = true;
        ap.closeAt = System.currentTimeMillis() + seconds * 1000L;
        Location c = ap.center.toLocation(ap.world);
        ap.world.playSound(c, Sound.BLOCK_BEACON_ACTIVATE, 2f, 1.2f);

        ap.closer = new BukkitRunnable() {
            @Override
            public void run() {
                long left = (ap.closeAt - System.currentTimeMillis() + 999L) / 1000L;
                if (left <= 0) {
                    closePortal(ap);
                    return;
                }
                Location cl = ap.center.toLocation(ap.world);
                ap.world.spawnParticle(Particle.CHERRY_LEAVES, cl, 14, 1.2, 1.5, 1.2, 0.0);
                for (Player pl : ap.world.getPlayers()) {
                    if (pl.getLocation().distanceSquared(cl) <= 24 * 24) {
                        pl.sendActionBar(Component.text("Portal menutup dalam " + left + " detik", NamedTextColor.LIGHT_PURPLE));
                    }
                }
            }
        };
        ap.closer.runTaskTimer(plugin, 0L, 20L);
    }

    private void closePortal(ActivePortal ap) {
        if (ap.closer != null) {
            try {
                ap.closer.cancel();
            } catch (IllegalStateException ignored) {
                // not scheduled
            }
            ap.closer = null;
        }
        portals.remove(ap.key);
        for (Block b : ap.interior) {
            if (b.getType() == Material.PINK_STAINED_GLASS_PANE) {
                b.setType(Material.AIR, false);
            }
        }
        Location c = ap.center.toLocation(ap.world);
        ap.world.playSound(c, Sound.BLOCK_GLASS_BREAK, 2f, 0.7f);
        ap.world.spawnParticle(Particle.CHERRY_LEAVES, c, 60, 1.5, 1.5, 1.5, 0.0);
    }

    // ------------------------------------------------------------------ entering the dimension

    private void checkContacts() {
        if (portals.isEmpty()) {
            return;
        }
        for (ActivePortal ap : new ArrayList<>(portals.values())) {
            if (!ap.open) {
                continue;
            }
            for (Player p : ap.world.getPlayers()) {
                if (cutscenes.containsKey(p.getUniqueId()) || p.getGameMode() == GameMode.SPECTATOR) {
                    continue;
                }
                if (ap.trigger.overlaps(p.getBoundingBox()) && plugin.tryWarp(p.getUniqueId())) {
                    enter(p, ap);
                }
            }
        }
    }

    private void enter(Player p, ActivePortal ap) {
        World cw = plugin.candyWorld().world();
        if (cw == null) {
            return;
        }
        plugin.returns().set(p.getUniqueId(), frontLocation(p, ap));

        Location from = p.getLocation();
        from.getWorld().spawnParticle(Particle.CHERRY_LEAVES, from.clone().add(0, 1, 0), 40, 0.6, 1.0, 0.6, 0.0);
        from.getWorld().playSound(from, Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f, 0.8f);

        Location dest = plugin.candyWorld().arrival();
        p.teleport(dest);
        dest.getWorld().playSound(dest, Sound.BLOCK_PORTAL_TRAVEL, 0.8f, 1.5f);
        dest.getWorld().spawnParticle(Particle.CHERRY_LEAVES, dest.clone().add(0, 1, 0), 60, 1.0, 1.5, 1.0, 0.0);
        p.showTitle(Title.title(
                Component.text("Candy Dimension", NamedTextColor.LIGHT_PURPLE),
                Component.text("Selamat datang di dunia permen!", NamedTextColor.WHITE)));
    }

    private Location frontLocation(Player p, ActivePortal ap) {
        double side = ap.planeX
                ? p.getLocation().getX() - ap.center.getX()
                : p.getLocation().getZ() - ap.center.getZ();
        double sign = side >= 0 ? 1.0 : -1.0;
        Location loc = p.getLocation().clone();
        if (ap.planeX) {
            loc.setX(ap.center.getX() + sign * 1.6);
        } else {
            loc.setZ(ap.center.getZ() + sign * 1.6);
        }
        if (!loc.getBlock().isPassable() || !loc.clone().add(0, 1, 0).getBlock().isPassable()) {
            loc = p.getLocation().clone();
        }
        return loc;
    }

    // ------------------------------------------------------------------ cutscene

    private final class Cutscene extends BukkitRunnable {

        private final Player player;
        private final ActivePortal portal;
        private final Location origin;
        private final GameMode oldMode;
        private final boolean oldAllowFlight;
        private final boolean oldFlying;
        private final float oldFly;
        private final float oldWalk;
        private final Vector center;
        private final Vector normal;
        private final Vector tangent;
        private final double startDist;
        private final double endDist;
        private final List<List<Block>> rows = new ArrayList<>();
        private final Random rnd = new Random();
        private int rowsPlaced = 0;
        private int tick = 0;
        private boolean done = false;
        private boolean exploded = false;

        Cutscene(Player player, ActivePortal portal) {
            this.player = player;
            this.portal = portal;
            this.origin = player.getLocation().clone();
            this.oldMode = player.getGameMode();
            this.oldAllowFlight = player.getAllowFlight();
            this.oldFlying = player.isFlying();
            this.oldFly = player.getFlySpeed();
            this.oldWalk = player.getWalkSpeed();
            this.center = portal.center.clone();

            double side = portal.planeX
                    ? player.getLocation().getX() - center.getX()
                    : player.getLocation().getZ() - center.getZ();
            double sign = side >= 0 ? 1.0 : -1.0;
            this.normal = portal.planeX ? new Vector(sign, 0, 0) : new Vector(0, 0, sign);
            this.tangent = portal.planeX ? new Vector(0, 0, 1) : new Vector(1, 0, 0);

            double maxDist = 12.0;
            RayTraceResult hit = portal.world.rayTraceBlocks(center.toLocation(portal.world), normal, maxDist,
                    FluidCollisionMode.NEVER, true);
            double clear = hit == null ? maxDist : Math.max(3.5, hit.getHitPosition().distance(center) - 1.0);
            this.startDist = clear;
            this.endDist = Math.max(3.2, clear * 0.55);

            TreeMap<Integer, List<Block>> byY = new TreeMap<>();
            for (Block b : portal.interior) {
                byY.computeIfAbsent(b.getY(), k -> new ArrayList<>()).add(b);
            }
            rows.addAll(byY.values());

            player.leaveVehicle();
            player.setGameMode(GameMode.SPECTATOR);
            player.setFlySpeed(0f);
        }

        @Override
        public void run() {
            if (done) {
                return;
            }
            if (!player.isOnline()) {
                finish(false);
                return;
            }
            tick++;
            World world = portal.world;
            Location centerLoc = center.toLocation(world);

            double prog = Math.min(1.0, tick / (double) EXPLODE_TICK);
            double e = prog * prog * (3 - 2 * prog);
            double dist = startDist + (endDist - startDist) * e;
            double lat = -4.0 * (1.0 - e);
            double up = 3.2 - 1.8 * e;

            Vector pos = center.clone()
                    .add(normal.clone().multiply(dist))
                    .add(tangent.clone().multiply(lat));
            pos.setY(center.getY() + up);
            Location cam = new Location(world, pos.getX(), pos.getY(), pos.getZ());
            cam.setDirection(center.clone().subtract(pos));

            if (tick == 1) {
                world.playSound(centerLoc, Sound.BLOCK_BEACON_ACTIVATE, 2f, 0.6f);
            }

            // panes appear row by row
            if (tick >= PANES_START && rowsPlaced < rows.size()) {
                int target = (int) Math.ceil((tick - PANES_START) / (double) (PANES_END - PANES_START) * rows.size());
                target = Math.min(target, rows.size());
                while (rowsPlaced < target) {
                    placeRow(portal, rows.get(rowsPlaced), rowsPlaced);
                    rowsPlaced++;
                }
            }

            // earthquake
            double shake = 0.0;
            if (tick >= SHAKE_START) {
                if (tick == SHAKE_START) {
                    world.playSound(centerLoc, Sound.ENTITY_ENDER_DRAGON_GROWL, 2f, 0.5f);
                }
                if (tick % 6 == 0) {
                    world.playSound(centerLoc, Sound.ENTITY_WARDEN_HEARTBEAT, 3f, 0.7f);
                }
                if (tick % 10 == 0) {
                    world.playSound(centerLoc, Sound.BLOCK_DEEPSLATE_BREAK, 3f, 0.5f);
                }
                if (tick % 2 == 0) {
                    world.spawnParticle(Particle.BLOCK, cam, 8, 3, 2, 3, Material.PINK_CONCRETE.createBlockData());
                }
                double ramp = Math.min(1.0, (tick - SHAKE_START) / (double) (EXPLODE_TICK - SHAKE_START));
                shake = 0.05 + 0.30 * ramp;
                if (tick > EXPLODE_TICK) {
                    shake = 0.55 * (1.0 - (tick - EXPLODE_TICK) / (double) (END_TICK - EXPLODE_TICK));
                }
            }

            // explosion
            if (tick == EXPLODE_TICK && !exploded) {
                exploded = true;
                world.spawnParticle(Particle.EXPLOSION_EMITTER, centerLoc, 3, 1.5, 1.5, 1.5, 0.0);
                world.spawnParticle(Particle.FIREWORK, centerLoc, 120, 2.5, 3.0, 2.5, 0.2);
                world.spawnParticle(Particle.CHERRY_LEAVES, centerLoc, 150, 3.0, 3.0, 3.0, 0.0);
                world.playSound(centerLoc, Sound.ENTITY_GENERIC_EXPLODE, 4f, 0.8f);
            }

            if (shake > 0.0) {
                cam.add((rnd.nextDouble() - 0.5) * shake, (rnd.nextDouble() - 0.5) * shake, (rnd.nextDouble() - 0.5) * shake);
                cam.setYaw(cam.getYaw() + (float) ((rnd.nextDouble() - 0.5) * shake * 14.0));
                cam.setPitch(cam.getPitch() + (float) ((rnd.nextDouble() - 0.5) * shake * 10.0));
            }

            player.teleport(cam);

            if (tick >= END_TICK) {
                finish(true);
            }
        }

        void finish(boolean success) {
            if (done) {
                return;
            }
            done = true;
            try {
                cancel();
            } catch (IllegalStateException ignored) {
                // not scheduled
            }
            cutscenes.remove(player.getUniqueId());

            if (success) {
                while (rowsPlaced < rows.size()) {
                    placeRow(portal, rows.get(rowsPlaced), rowsPlaced);
                    rowsPlaced++;
                }
            }

            player.setFlySpeed(oldFly);
            player.setWalkSpeed(oldWalk);
            player.setGameMode(oldMode);
            player.setAllowFlight(oldAllowFlight);
            player.setFlying(oldAllowFlight && oldFlying);
            player.teleport(origin);

            if (success) {
                openPortal(portal);
                player.showTitle(Title.title(
                        Component.text("Portal Terbuka!", NamedTextColor.LIGHT_PURPLE),
                        Component.text("Masuk sebelum portal menutup", NamedTextColor.WHITE),
                        Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(800))));
            } else {
                closePortal(portal);
            }
        }
    }
}
