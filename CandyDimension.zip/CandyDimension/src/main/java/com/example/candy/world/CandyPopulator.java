package com.example.candy.world;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Leaves;
import org.bukkit.generator.BlockPopulator;
import org.bukkit.generator.LimitedRegion;
import org.bukkit.generator.WorldInfo;

import java.util.Random;

/** Places all candy structures: lollipops, canes, wrapped candy, gumdrops, trees, houses, rainbows and boss arenas. */
public final class CandyPopulator extends BlockPopulator {

    private static final Material[] CANDY = {
            Material.RED_CONCRETE, Material.ORANGE_CONCRETE, Material.YELLOW_CONCRETE, Material.LIME_CONCRETE,
            Material.LIGHT_BLUE_CONCRETE, Material.MAGENTA_CONCRETE, Material.PINK_CONCRETE, Material.PURPLE_CONCRETE
    };
    private static final Material[] CANDY_GLASS = {
            Material.RED_STAINED_GLASS, Material.ORANGE_STAINED_GLASS, Material.YELLOW_STAINED_GLASS,
            Material.LIME_STAINED_GLASS, Material.LIGHT_BLUE_STAINED_GLASS, Material.MAGENTA_STAINED_GLASS,
            Material.PINK_STAINED_GLASS, Material.PURPLE_STAINED_GLASS
    };
    private static final Material[] RAINBOW = {
            Material.RED_CONCRETE, Material.ORANGE_CONCRETE, Material.YELLOW_CONCRETE, Material.LIME_CONCRETE,
            Material.LIGHT_BLUE_CONCRETE, Material.BLUE_CONCRETE, Material.PURPLE_CONCRETE
    };
    private static final Material[] ORNAMENTS = {
            Material.GOLD_BLOCK, Material.RED_CONCRETE, Material.SEA_LANTERN,
            Material.MAGENTA_STAINED_GLASS, Material.WHITE_CONCRETE, Material.GLOWSTONE
    };

    private final long seed;
    private final CandyTerrain terrain;
    private final BlockData leaves;

    public CandyPopulator(long seed, CandyTerrain terrain) {
        this.seed = seed;
        this.terrain = terrain;
        Leaves l = (Leaves) Bukkit.createBlockData(Material.CHERRY_LEAVES);
        l.setPersistent(true);
        this.leaves = l;
    }

    /** Deterministic: decides whether a chunk holds a Candy Boss arena. */
    public static boolean isBossChunk(long seed, int cx, int cz) {
        long dx = cx * 16L + 8L;
        long dz = cz * 16L + 8L;
        if (dx * dx + dz * dz < 160L * 160L) {
            return false;
        }
        long h = seed;
        h ^= cx * 0x9E3779B97F4A7C15L;
        h = Long.rotateLeft(h, 31) ^ (cz * 0xC2B2AE3D27D4EB4FL);
        h ^= h >>> 33;
        h *= 0xff51afd7ed558ccdL;
        h ^= h >>> 33;
        return Math.floorMod(h, 70L) == 0L;
    }

    /** Small wrapper that ignores blocks outside the region we are allowed to edit. */
    private static final class B {
        private final LimitedRegion r;

        B(LimitedRegion r) {
            this.r = r;
        }

        void set(int x, int y, int z, Material m) {
            if (r.isInRegion(x, y, z)) {
                r.setType(x, y, z, m);
            }
        }

        void set(int x, int y, int z, BlockData d) {
            if (r.isInRegion(x, y, z)) {
                r.setBlockData(x, y, z, d);
            }
        }
    }

    @Override
    public void populate(WorldInfo info, Random random, int chunkX, int chunkZ, LimitedRegion region) {
        B b = new B(region);
        int bx = chunkX * 16;
        int bz = chunkZ * 16;

        if (isBossChunk(seed, chunkX, chunkZ)) {
            bossArena(b, bx + 8, bz + 8);
            return;
        }

        scatter(b, random, bx, bz);

        int cx = bx + 4 + random.nextInt(8);
        int cz = bz + 4 + random.nextInt(8);
        if ((long) cx * cx + (long) cz * cz < 30L * 30L) {
            return;
        }

        double roll = random.nextDouble();
        if (roll < 0.05) {
            house(b, cx, cz);
        } else if (roll < 0.09) {
            rainbow(b, bx + 8, bz + 8, random);
        } else if (roll < 0.23) {
            lollipop(b, cx, cz, random);
        } else if (roll < 0.37) {
            candyCane(b, cx, cz, random);
        } else if (roll < 0.49) {
            wrappedCandy(b, cx, cz, random);
        } else if (roll < 0.67) {
            gumdrops(b, cx, cz, random);
        } else if (roll < 0.95) {
            candyTree(b, cx, cz, random);
        }
    }

    // ------------------------------------------------------------------ small decorations

    private void scatter(B b, Random rnd, int bx, int bz) {
        int candies = rnd.nextInt(4);
        for (int i = 0; i < candies; i++) {
            miniCandy(b, bx + rnd.nextInt(12), bz + rnd.nextInt(12), rnd);
        }
        for (int i = 0; i < 10; i++) {
            if (rnd.nextDouble() < 0.55) {
                int x = bx + rnd.nextInt(16);
                int z = bz + rnd.nextInt(16);
                b.set(x, terrain.height(x, z), z, Material.PINK_PETALS);
            }
        }
    }

    private void miniCandy(B b, int x, int z, Random rnd) {
        int idx = rnd.nextInt(CANDY.length);
        boolean alongX = rnd.nextBoolean();
        int y = terrain.height(x, z);
        for (int u = 0; u < 3; u++) {
            Material m = (u % 2 == 0) ? CANDY[idx] : Material.WHITE_CONCRETE;
            if (alongX) {
                b.set(x + u, y, z, m);
            } else {
                b.set(x, y, z + u, m);
            }
        }
        if (alongX) {
            b.set(x - 1, y, z, CANDY_GLASS[idx]);
            b.set(x + 3, y, z, CANDY_GLASS[idx]);
        } else {
            b.set(x, y, z - 1, CANDY_GLASS[idx]);
            b.set(x, y, z + 3, CANDY_GLASS[idx]);
        }
    }

    // ------------------------------------------------------------------ giant lollipop

    private void lollipop(B b, int x, int z, Random rnd) {
        int y0 = terrain.height(x, z);
        int stick = 11 + rnd.nextInt(7);
        for (int y = y0 - 3; y < y0 + stick; y++) {
            b.set(x, y, z, ((y - y0 + 3) / 2) % 2 == 0 ? Material.WHITE_CONCRETE : Material.PINK_CONCRETE);
        }
        int r = 5 + rnd.nextInt(3);
        int cy = y0 + stick + r - 1;
        boolean alongX = rnd.nextBoolean();
        Material c1 = CANDY[rnd.nextInt(CANDY.length)];
        Material c2 = Material.WHITE_CONCRETE;
        for (int u = -r; u <= r; u++) {
            for (int v = -r; v <= r; v++) {
                double rr = Math.sqrt(u * u + v * v);
                if (rr > r + 0.35) {
                    continue;
                }
                double ang = (Math.atan2(v, u) + Math.PI) / (2 * Math.PI);
                int band = (int) Math.floor(rr * 0.85 + ang * 2.0);
                Material m = (band % 2 == 0) ? c1 : c2;
                for (int t = 0; t < 2; t++) {
                    if (alongX) {
                        b.set(x + u, cy + v, z + t, m);
                    } else {
                        b.set(x + t, cy + v, z + u, m);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ candy cane

    private void candyCane(B b, int x, int z, Random rnd) {
        int y0 = terrain.height(x, z);
        int h = 12 + rnd.nextInt(5);
        boolean alongX = rnd.nextBoolean();
        int dir = rnd.nextBoolean() ? 1 : -1;

        for (int y = y0 - 3; y < y0 + h; y++) {
            Material m = (((y - y0 + 3) / 2) % 2 == 0) ? Material.RED_CONCRETE : Material.WHITE_CONCRETE;
            for (int dx = 0; dx < 2; dx++) {
                for (int dz = 0; dz < 2; dz++) {
                    b.set(x + dx, y, z + dz, m);
                }
            }
        }

        int yTop = y0 + h - 1;
        int radius = 4;
        for (double theta = 0.0; theta <= Math.PI + 0.001; theta += 0.04) {
            int u = (int) Math.round(dir * (radius - radius * Math.cos(theta)));
            int y = yTop + (int) Math.round(radius * Math.sin(theta));
            Material m = (((int) (theta * radius / 2.0)) % 2 == 0) ? Material.RED_CONCRETE : Material.WHITE_CONCRETE;
            caneBlock(b, x, z, alongX, u, y, m);
        }
        int endU = 2 * radius * dir;
        for (int i = 1; i <= 3; i++) {
            Material m = (i % 2 == 0) ? Material.RED_CONCRETE : Material.WHITE_CONCRETE;
            caneBlock(b, x, z, alongX, endU, yTop - i, m);
        }
    }

    private void caneBlock(B b, int x, int z, boolean alongX, int u, int y, Material m) {
        for (int du = 0; du < 2; du++) {
            for (int dy = 0; dy < 2; dy++) {
                for (int dv = 0; dv < 2; dv++) {
                    if (alongX) {
                        b.set(x + u + du, y + dy, z + dv, m);
                    } else {
                        b.set(x + dv, y + dy, z + u + du, m);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ giant wrapped candy

    private void wrappedCandy(B b, int x, int z, Random rnd) {
        int cy = terrain.height(x, z) + 2;
        boolean alongX = rnd.nextBoolean();
        int idx = rnd.nextInt(CANDY.length);
        Material body = CANDY[idx];
        Material glass = CANDY_GLASS[idx];
        int a = 6;
        int r = 3;

        for (int u = -a; u <= a; u++) {
            for (int v = -r; v <= r; v++) {
                for (int w = -r; w <= r; w++) {
                    double e = (u * u) / (double) (a * a) + (v * v + w * w) / (double) (r * r);
                    if (e > 1.0) {
                        continue;
                    }
                    Material m = (((u + a) / 2) % 2 == 0) ? body : Material.WHITE_CONCRETE;
                    if (alongX) {
                        b.set(x + u, cy + v, z + w, m);
                    } else {
                        b.set(x + w, cy + v, z + u, m);
                    }
                }
            }
        }

        for (int k = 1; k <= 4; k++) {
            for (int w = -k; w <= k; w++) {
                for (int dy = -(k / 2); dy <= k / 2; dy++) {
                    if (alongX) {
                        b.set(x + a + k, cy + dy, z + w, glass);
                        b.set(x - a - k, cy + dy, z + w, glass);
                    } else {
                        b.set(x + w, cy + dy, z + a + k, glass);
                        b.set(x + w, cy + dy, z - a - k, glass);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ gumdrops

    private void gumdrops(B b, int x, int z, Random rnd) {
        int count = 3 + rnd.nextInt(3);
        for (int i = 0; i < count; i++) {
            int ox = x + rnd.nextInt(13) - 6;
            int oz = z + rnd.nextInt(13) - 6;
            int r = 2 + rnd.nextInt(3);
            gumdrop(b, ox, oz, r, CANDY[rnd.nextInt(CANDY.length)]);
        }
    }

    private void gumdrop(B b, int x, int z, int r, Material m) {
        int y0 = terrain.height(x, z);
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                for (int dy = -2; dy <= r; dy++) {
                    boolean inside;
                    if (dy < 0) {
                        inside = dx * dx + dz * dz <= r * r;
                    } else {
                        inside = dx * dx + dy * dy + dz * dz <= r * r + 1;
                    }
                    if (inside) {
                        b.set(x + dx, y0 + dy, z + dz, m);
                    }
                }
            }
        }
        b.set(x, y0 + r + 1, z, Material.WHITE_CONCRETE);
    }

    // ------------------------------------------------------------------ rainbow

    private void rainbow(B b, int cx, int cz, Random rnd) {
        boolean alongX = rnd.nextBoolean();
        int radius = 13;
        int yb = terrain.height(cx, cz) - 1;
        for (int u = -radius; u <= radius; u++) {
            for (int dy = -5; dy <= radius; dy++) {
                double rad = Math.sqrt(u * u + dy * dy);
                int band = (int) Math.floor(radius - rad);
                if (band < 0 || band >= RAINBOW.length) {
                    continue;
                }
                for (int v = -1; v <= 1; v++) {
                    if (alongX) {
                        b.set(cx + u, yb + dy, cz + v, RAINBOW[band]);
                    } else {
                        b.set(cx + v, yb + dy, cz + u, RAINBOW[band]);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ candy tree

    private void candyTree(B b, int x, int z, Random rnd) {
        int y0 = terrain.height(x, z);
        int h = 12 + rnd.nextInt(6);
        int start = y0 + 4;
        int top = y0 + h + 2;

        for (int y = y0 - 2; y <= top; y++) {
            b.set(x, y, z, ((y - y0 + 2) / 2) % 2 == 0 ? Material.RED_CONCRETE : Material.WHITE_CONCRETE);
        }

        for (int y = start; y <= top; y++) {
            double p = (y - start) / (double) (top - start);
            double radius = 5.6 * (1.0 - p) + 1.0;
            if ((y - start) % 3 == 0) {
                radius += 1.4;
            }
            int ir = (int) Math.ceil(radius);
            for (int dx = -ir; dx <= ir; dx++) {
                for (int dz = -ir; dz <= ir; dz++) {
                    if (dx == 0 && dz == 0) {
                        continue;
                    }
                    double d = Math.sqrt(dx * dx + dz * dz);
                    if (d > radius) {
                        continue;
                    }
                    if (d > radius - 1.3 && rnd.nextDouble() < 0.12) {
                        b.set(x + dx, y, z + dz, ORNAMENTS[rnd.nextInt(ORNAMENTS.length)]);
                    } else {
                        b.set(x + dx, y, z + dz, leaves);
                    }
                }
            }
        }
        b.set(x, top + 1, z, Material.GOLD_BLOCK);
        b.set(x, top + 2, z, Material.END_ROD);
    }

    // ------------------------------------------------------------------ candy house

    private void house(B b, int cx, int cz) {
        int fy = terrain.height(cx, cz) - 1;

        // clear the space
        for (int dx = -7; dx <= 7; dx++) {
            for (int dz = -6; dz <= 6; dz++) {
                for (int dy = 1; dy <= 14; dy++) {
                    b.set(cx + dx, fy + dy, cz + dz, Material.AIR);
                }
            }
        }

        // foundation, porch and floor
        for (int dx = -6; dx <= 6; dx++) {
            for (int dz = -5; dz <= 5; dz++) {
                for (int dy = -5; dy <= -1; dy++) {
                    b.set(cx + dx, fy + dy, cz + dz, Material.PINK_TERRACOTTA);
                }
                Material floor;
                if (Math.abs(dx) <= 5 && Math.abs(dz) <= 4) {
                    if (Math.abs(dx) == 3 && Math.abs(dz) == 2) {
                        floor = Material.GLOWSTONE;
                    } else {
                        floor = ((dx + dz) & 1) == 0 ? Material.PINK_CONCRETE : Material.WHITE_CONCRETE;
                    }
                } else {
                    floor = Material.WHITE_CONCRETE;
                }
                b.set(cx + dx, fy, cz + dz, floor);
            }
        }

        // walls
        for (int dx = -5; dx <= 5; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                boolean perimeter = Math.abs(dx) == 5 || Math.abs(dz) == 4;
                if (!perimeter) {
                    continue;
                }
                for (int dy = 1; dy <= 4; dy++) {
                    Material m;
                    if (Math.abs(dx) == 5 && Math.abs(dz) == 4) {
                        m = (dy % 2 == 0) ? Material.RED_CONCRETE : Material.WHITE_CONCRETE;
                    } else {
                        m = (dy % 2 == 1) ? Material.PINK_CONCRETE : Material.WHITE_CONCRETE;
                    }
                    boolean window = (dy == 2 || dy == 3)
                            && ((Math.abs(dz) == 4 && (dx == -3 || dx == 3)) || (Math.abs(dx) == 5 && dz == 0));
                    if (window) {
                        m = Material.PINK_STAINED_GLASS_PANE;
                    }
                    if (dz == 4 && dx == 0 && dy <= 2) {
                        m = Material.AIR;
                    }
                    b.set(cx + dx, fy + dy, cz + dz, m);
                }
            }
        }

        // roof (gable along X, two blocks thick)
        for (int k = 0; k <= 5; k++) {
            int zc = 5 - k;
            Material m = (k == 5) ? Material.WHITE_CONCRETE : (k % 2 == 0 ? Material.RED_CONCRETE : Material.PINK_CONCRETE);
            for (int dx = -6; dx <= 6; dx++) {
                for (int t = 0; t <= 1; t++) {
                    int z = zc - t;
                    if (z < 0) {
                        continue;
                    }
                    b.set(cx + dx, fy + 5 + k, cz + z, m);
                    b.set(cx + dx, fy + 5 + k, cz - z, m);
                }
            }
            // gable end walls
            if (k <= 4) {
                for (int z = -(4 - k); z <= (4 - k); z++) {
                    b.set(cx - 5, fy + 5 + k, cz + z, Material.WHITE_CONCRETE);
                    b.set(cx + 5, fy + 5 + k, cz + z, Material.WHITE_CONCRETE);
                }
            }
        }

        // interior: tables with cakes and candles
        b.set(cx - 3, fy + 1, cz - 2, Material.CHERRY_SLAB);
        b.set(cx - 3, fy + 2, cz - 2, Material.CAKE);
        b.set(cx + 3, fy + 1, cz - 2, Material.CHERRY_SLAB);
        b.set(cx + 3, fy + 2, cz - 2, Material.PINK_CANDLE);
        b.set(cx, fy + 1, cz - 3, Material.CHERRY_SLAB);
        b.set(cx, fy + 2, cz - 3, Material.CAKE);

        // outside: gumdrops next to the door
        gumdrop(b, cx - 3, cz + 7, 2, Material.MAGENTA_CONCRETE);
        gumdrop(b, cx + 3, cz + 7, 2, Material.LIGHT_BLUE_CONCRETE);
    }

    // ------------------------------------------------------------------ boss arena

    private void bossArena(B b, int cx, int cz) {
        int fy = terrain.height(cx, cz) - 1;
        int radius = 12;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double d = Math.sqrt(dx * dx + dz * dz);
                if (d > radius + 0.5) {
                    continue;
                }
                for (int dy = 1; dy <= 18; dy++) {
                    b.set(cx + dx, fy + dy, cz + dz, Material.AIR);
                }
                for (int dy = -8; dy <= -1; dy++) {
                    b.set(cx + dx, fy + dy, cz + dz, Material.PINK_TERRACOTTA);
                }
                Material floor;
                if (d > radius - 1.0) {
                    floor = Material.MAGENTA_CONCRETE;
                } else {
                    floor = (((int) d) / 2) % 2 == 0 ? Material.PINK_CONCRETE : Material.WHITE_CONCRETE;
                }
                b.set(cx + dx, fy, cz + dz, floor);
            }
        }

        // six candy cane pillars
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3.0;
            int px = cx + (int) Math.round(Math.cos(a) * 9.0);
            int pz = cz + (int) Math.round(Math.sin(a) * 9.0);
            for (int y = 1; y <= 9; y++) {
                Material m = ((y / 2) % 2 == 0) ? Material.RED_CONCRETE : Material.WHITE_CONCRETE;
                for (int ox = 0; ox < 2; ox++) {
                    for (int oz = 0; oz < 2; oz++) {
                        b.set(px + ox, fy + y, pz + oz, m);
                    }
                }
            }
            for (int ox = 0; ox < 2; ox++) {
                for (int oz = 0; oz < 2; oz++) {
                    b.set(px + ox, fy + 10, pz + oz, Material.SEA_LANTERN);
                }
            }
        }

        // golden altar, the crying obsidian block in the middle is the boss marker
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                b.set(cx + dx, fy, cz + dz, Material.GOLD_BLOCK);
            }
        }
        b.set(cx, fy, cz, Material.CRYING_OBSIDIAN);
    }
}
