package com.example.candy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.GlassPane;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/** Random exit portals that appear near players inside the Candy Dimension. */
public final class ExitPortalManager {

    private record Saved(Block block, BlockData data) {
    }

    private static final class ExitPortal {
        final World world;
        final Vector center;
        final BoundingBox trigger;
        final List<Saved> saved = new ArrayList<>();
        final long expiresAt;

        ExitPortal(World world, Vector center, BoundingBox trigger, long expiresAt) {
            this.world = world;
            this.center = center;
            this.trigger = trigger;
            this.expiresAt = expiresAt;
        }
    }

    private final CandyPlugin plugin;
    private final List<ExitPortal> portals = new ArrayList<>();
    private final Random random = new Random();
    private BukkitRunnable task;
    private int tick = 0;
    private int secondsSinceRoll = 0;

    public ExitPortalManager(CandyPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                tick++;
                if (tick % 3 == 0) {
                    contacts();
                }
                if (tick % 20 == 0) {
                    secondly();
                }
            }
        };
        task.runTaskTimer(plugin, 20L, 1L);
    }

    public void shutdown() {
        for (ExitPortal ep : new ArrayList<>(portals)) {
            restore(ep);
        }
        portals.clear();
    }

    // ------------------------------------------------------------------ ticking

    private void contacts() {
        World w = plugin.candyWorld().world();
        if (w == null || portals.isEmpty()) {
            return;
        }
        for (Player p : w.getPlayers()) {
            if (p.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            for (ExitPortal ep : new ArrayList<>(portals)) {
                if (ep.trigger.overlaps(p.getBoundingBox()) && plugin.tryWarp(p.getUniqueId())) {
                    leave(p);
                    break;
                }
            }
        }
    }

    private void secondly() {
        long now = System.currentTimeMillis();
        Iterator<ExitPortal> it = portals.iterator();
        while (it.hasNext()) {
            ExitPortal ep = it.next();
            if (now >= ep.expiresAt) {
                restore(ep);
                it.remove();
                continue;
            }
            // light beam so the portal can be spotted from far away
            ep.world.spawnParticle(Particle.END_ROD, ep.center.getX(), ep.center.getY() + 3, ep.center.getZ(),
                    30, 0.25, 8.0, 0.25, 0.01, null, true);
            ep.world.spawnParticle(Particle.CHERRY_LEAVES, ep.center.getX(), ep.center.getY(), ep.center.getZ(),
                    10, 1.0, 1.5, 1.0, 0.0);
        }

        World w = plugin.candyWorld().world();
        if (w == null) {
            return;
        }
        secondsSinceRoll++;
        int every = plugin.getConfig().getInt("exit-portal.check-seconds", 30);
        if (secondsSinceRoll < every) {
            return;
        }
        secondsSinceRoll = 0;
        double chance = plugin.getConfig().getDouble("exit-portal.chance", 0.5);
        for (Player p : w.getPlayers()) {
            if (p.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            if (random.nextDouble() > chance) {
                continue;
            }
            if (hasNearby(p)) {
                continue;
            }
            spawnNear(p);
        }
    }

    private boolean hasNearby(Player p) {
        Location pl = p.getLocation();
        for (ExitPortal ep : portals) {
            if (ep.world.equals(pl.getWorld())) {
                double dx = ep.center.getX() - pl.getX();
                double dz = ep.center.getZ() - pl.getZ();
                if (dx * dx + dz * dz < 90.0 * 90.0) {
                    return true;
                }
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ spawning

    private void spawnNear(Player p) {
        World w = p.getWorld();
        int bx = 0;
        int bz = 0;
        int ground = 0;
        boolean found = false;
        for (int attempt = 0; attempt < 8; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = 20 + random.nextDouble() * 25;
            int x = (int) Math.round(p.getLocation().getX() + Math.cos(angle) * dist);
            int z = (int) Math.round(p.getLocation().getZ() + Math.sin(angle) * dist);
            if (!w.isChunkLoaded(x >> 4, z >> 4)) {
                continue;
            }
            int g = plugin.candyWorld().terrain().height(x, z);
            bx = x;
            bz = z;
            ground = g;
            found = true;
            if (w.getHighestBlockYAt(x, z) + 1 == g) {
                break;
            }
        }
        if (!found) {
            return;
        }

        boolean planeX = random.nextBoolean();
        long expires = System.currentTimeMillis() + plugin.getConfig().getInt("exit-portal.lifetime-seconds", 120) * 1000L;

        GlassPane pane = (GlassPane) Material.MAGENTA_STAINED_GLASS_PANE.createBlockData();
        if (planeX) {
            pane.setFace(BlockFace.NORTH, true);
            pane.setFace(BlockFace.SOUTH, true);
        } else {
            pane.setFace(BlockFace.EAST, true);
            pane.setFace(BlockFace.WEST, true);
        }

        List<Saved> saved = new ArrayList<>();

        // clear a walkway in front of and behind the portal
        for (int a = -2; a <= 2; a++) {
            for (int n = -2; n <= 2; n++) {
                if (n == 0) {
                    continue;
                }
                for (int y = 0; y <= 3; y++) {
                    Block b = planeX ? w.getBlockAt(bx + n, ground + y, bz + a) : w.getBlockAt(bx + a, ground + y, bz + n);
                    if (!b.getType().isAir()) {
                        saved.add(new Saved(b, b.getBlockData()));
                        b.setType(Material.AIR, false);
                    }
                }
            }
        }

        // frame (sides and top) and the pane interior
        for (int a = -2; a <= 2; a++) {
            for (int y = 0; y <= 4; y++) {
                boolean frame = Math.abs(a) == 2 || y == 4;
                Block b = planeX ? w.getBlockAt(bx, ground + y, bz + a) : w.getBlockAt(bx + a, ground + y, bz);
                saved.add(new Saved(b, b.getBlockData()));
                if (frame) {
                    Material m;
                    if (y == 4 && Math.abs(a) == 2) {
                        m = Material.GOLD_BLOCK;
                    } else {
                        m = ((a + 2 + y) % 2 == 0) ? Material.RED_CONCRETE : Material.WHITE_CONCRETE;
                    }
                    b.setType(m, false);
                } else {
                    b.setBlockData(pane, false);
                }
            }
        }

        double cx = bx + 0.5;
        double cy = ground + 2.0;
        double cz = bz + 0.5;
        Vector center = new Vector(cx, cy, cz);
        BoundingBox trigger = planeX
                ? new BoundingBox(bx, ground, bz - 1, bx + 1, ground + 4, bz + 2)
                : new BoundingBox(bx - 1, ground, bz, bx + 2, ground + 4, bz + 1);
        if (planeX) {
            trigger.expand(0.65, 0.0, 0.0);
        } else {
            trigger.expand(0.0, 0.0, 0.65);
        }

        ExitPortal ep = new ExitPortal(w, center, trigger, expires);
        ep.saved.addAll(saved);
        portals.add(ep);

        w.playSound(center.toLocation(w), Sound.BLOCK_BEACON_ACTIVATE, 2f, 1.4f);
        p.sendMessage(Component.text("✦ Portal keluar muncul di sekitar X " + bx + ", Y " + ground + ", Z " + bz
                + "! Cari cahaya putihnya.", NamedTextColor.LIGHT_PURPLE));
    }

    private void restore(ExitPortal ep) {
        for (int i = ep.saved.size() - 1; i >= 0; i--) {
            Saved s = ep.saved.get(i);
            s.block().setBlockData(s.data(), false);
        }
        ep.world.playSound(ep.center.toLocation(ep.world), Sound.BLOCK_GLASS_BREAK, 2f, 0.8f);
    }

    // ------------------------------------------------------------------ leaving

    private void leave(Player p) {
        Location dest = plugin.returns().get(p.getUniqueId());
        if (dest == null) {
            dest = Bukkit.getWorlds().get(0).getSpawnLocation();
        }
        Location from = p.getLocation();
        from.getWorld().spawnParticle(Particle.CHERRY_LEAVES, from.clone().add(0, 1, 0), 40, 0.6, 1.0, 0.6, 0.0);
        from.getWorld().playSound(from, Sound.ENTITY_ENDERMAN_TELEPORT, 1.5f, 1.2f);
        p.teleport(dest);
        plugin.returns().remove(p.getUniqueId());
        dest.getWorld().playSound(dest, Sound.BLOCK_PORTAL_TRAVEL, 0.8f, 1.2f);
        p.showTitle(Title.title(
                Component.text("Kembali ke Overworld", NamedTextColor.LIGHT_PURPLE),
                Component.text("Sampai jumpa, dunia permen!", NamedTextColor.WHITE)));
    }

    /** Used by /candy exit. */
    public void sendBack(Player p) {
        leave(p);
    }
}
