package com.example.candy;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Slime;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Random;

/** Candy Shard drops, Candy Slime stats and mob spawning inside the Candy Dimension. */
public final class MobListener implements Listener {

    private static final String SLIME_NAME = "Candy Slime";

    private final CandyPlugin plugin;
    private final NamespacedKey buffedKey;
    private final Random random = new Random();

    public MobListener(CandyPlugin plugin) {
        this.plugin = plugin;
        this.buffedKey = new NamespacedKey(plugin, "candy_slime_buffed");
    }

    // ------------------------------------------------------------------ shard drops

    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        LivingEntity ent = e.getEntity();
        if (plugin.boss().isBoss(ent)) {
            return;
        }
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("shard-drops." + ent.getType().name());
        if (sec == null) {
            return;
        }
        double chance = sec.getDouble("chance", 0.0);
        int amount = Math.max(1, sec.getInt("amount", 1));
        if (random.nextDouble() >= chance) {
            return;
        }
        if (plugin.candyWorld().isCandy(ent.getWorld())) {
            amount *= Math.max(1, plugin.getConfig().getInt("candy-world.shard-multiplier", 3));
        }
        e.getDrops().add(plugin.items().shard(amount));
    }

    // ------------------------------------------------------------------ Candy Slime

    private boolean isCandySlime(Slime slime) {
        Component c = slime.customName();
        return c != null && SLIME_NAME.equals(PlainTextComponentSerializer.plainText().serialize(c));
    }

    @EventHandler
    public void onSpawn(CreatureSpawnEvent e) {
        if (!(e.getEntity() instanceof Slime slime)) {
            return;
        }
        if (!isCandySlime(slime)) {
            return;
        }
        PersistentDataContainer pdc = slime.getPersistentDataContainer();
        if (pdc.has(buffedKey, PersistentDataType.BYTE)) {
            return;
        }
        pdc.set(buffedKey, PersistentDataType.BYTE, (byte) 1);
        slime.setCustomNameVisible(true);

        double hpMult = plugin.getConfig().getDouble("candy-slime.health-multiplier", 3.0);
        double dmgMult = plugin.getConfig().getDouble("candy-slime.damage-multiplier", 1.8);
        AttributeInstance hp = slime.getAttribute(Attribute.MAX_HEALTH);
        if (hp != null) {
            hp.setBaseValue(hp.getBaseValue() * hpMult);
            slime.setHealth(hp.getBaseValue());
        }
        AttributeInstance dmg = slime.getAttribute(Attribute.ATTACK_DAMAGE);
        if (dmg != null) {
            dmg.setBaseValue(dmg.getBaseValue() * dmgMult);
        }
    }

    // ------------------------------------------------------------------ spawning in the Candy Dimension

    public void startSpawner() {
        new BukkitRunnable() {
            @Override
            public void run() {
                spawnTick();
            }
        }.runTaskTimer(plugin, 100L, 100L);
    }

    private void spawnTick() {
        World cw = plugin.candyWorld().world();
        if (cw == null) {
            return;
        }
        int maxSlimes = plugin.getConfig().getInt("candy-slime.max-nearby", 8);
        for (Player p : cw.getPlayers()) {
            if (p.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            int slimes = 0;
            int others = 0;
            for (Entity en : p.getNearbyEntities(48, 48, 48)) {
                if (en instanceof Slime s && isCandySlime(s)) {
                    slimes++;
                } else {
                    EntityType t = en.getType();
                    if (t == EntityType.ZOMBIE || t == EntityType.SKELETON || t == EntityType.PANDA) {
                        others++;
                    }
                }
            }
            if (slimes < maxSlimes && random.nextDouble() < 0.8) {
                Location spot = pickSpot(p, cw);
                if (spot != null) {
                    int size = 2 + random.nextInt(3);
                    cw.spawn(spot, Slime.class, s -> {
                        s.setSize(size);
                        s.customName(Component.text(SLIME_NAME, NamedTextColor.LIGHT_PURPLE));
                        s.setCustomNameVisible(true);
                    });
                }
            }
            if (others < 6 && random.nextDouble() < 0.4) {
                Location spot = pickSpot(p, cw);
                if (spot != null) {
                    long time = cw.getTime();
                    boolean night = time >= 13000 && time <= 23000;
                    EntityType type;
                    if (night) {
                        int r = random.nextInt(3);
                        type = r == 0 ? EntityType.ZOMBIE : (r == 1 ? EntityType.SKELETON : EntityType.PANDA);
                    } else {
                        type = EntityType.PANDA;
                    }
                    cw.spawnEntity(spot, type);
                }
            }
        }
    }

    private Location pickSpot(Player p, World w) {
        for (int attempt = 0; attempt < 6; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = 20 + random.nextDouble() * 20;
            int x = (int) Math.round(p.getLocation().getX() + Math.cos(angle) * dist);
            int z = (int) Math.round(p.getLocation().getZ() + Math.sin(angle) * dist);
            if (!w.isChunkLoaded(x >> 4, z >> 4)) {
                continue;
            }
            int y = w.getHighestBlockYAt(x, z) + 1;
            Location loc = new Location(w, x + 0.5, y, z + 0.5);
            if (loc.getBlock().isPassable()) {
                return loc;
            }
        }
        return null;
    }
}
