package com.example.candy;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/** Remembers where each player stood in front of the Overworld portal. */
public final class ReturnStore {

    private final CandyPlugin plugin;
    private final File file;
    private final YamlConfiguration yml;

    public ReturnStore(CandyPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "returns.yml");
        this.yml = YamlConfiguration.loadConfiguration(file);
    }

    public void set(UUID id, Location loc) {
        if (loc.getWorld() == null) {
            return;
        }
        String p = id.toString();
        yml.set(p + ".world", loc.getWorld().getName());
        yml.set(p + ".x", loc.getX());
        yml.set(p + ".y", loc.getY());
        yml.set(p + ".z", loc.getZ());
        yml.set(p + ".yaw", (double) loc.getYaw());
        yml.set(p + ".pitch", (double) loc.getPitch());
        save();
    }

    public Location get(UUID id) {
        String p = id.toString();
        String worldName = yml.getString(p + ".world");
        if (worldName == null) {
            return null;
        }
        World world = Bukkit.getWorld(worldName);
        if (world == null) {
            return null;
        }
        return new Location(world,
                yml.getDouble(p + ".x"),
                yml.getDouble(p + ".y"),
                yml.getDouble(p + ".z"),
                (float) yml.getDouble(p + ".yaw"),
                (float) yml.getDouble(p + ".pitch"));
    }

    public void remove(UUID id) {
        yml.set(id.toString(), null);
        save();
    }

    private void save() {
        try {
            if (!plugin.getDataFolder().exists()) {
                plugin.getDataFolder().mkdirs();
            }
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("Could not save returns.yml: " + e.getMessage());
        }
    }
}
