package com.example.candy;

import com.example.candy.world.CandyChunkGenerator;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.PluginCommand;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class CandyPlugin extends JavaPlugin {

    private CandyItems items;
    private CandyWorld candyWorld;
    private ReturnStore returns;
    private PortalManager portals;
    private ExitPortalManager exitPortals;
    private BossManager boss;
    private MobListener mobs;
    private NamespacedKey discRecipeKey;
    private final Map<UUID, Long> warpCooldown = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        items = new CandyItems(this);
        returns = new ReturnStore(this);
        candyWorld = new CandyWorld(this);
        candyWorld.load();

        registerDiscRecipe();

        portals = new PortalManager(this);
        exitPortals = new ExitPortalManager(this);
        boss = new BossManager(this);
        mobs = new MobListener(this);
        ItemListener itemListener = new ItemListener(this);

        Bukkit.getPluginManager().registerEvents(portals, this);
        Bukkit.getPluginManager().registerEvents(boss, this);
        Bukkit.getPluginManager().registerEvents(mobs, this);
        Bukkit.getPluginManager().registerEvents(itemListener, this);

        portals.start();
        exitPortals.start();
        boss.start();
        mobs.startSpawner();

        PluginCommand cmd = getCommand("candy");
        if (cmd != null) {
            CandyCommand handler = new CandyCommand(this);
            cmd.setExecutor(handler);
            cmd.setTabCompleter(handler);
        }
        getLogger().info("CandyDimension enabled.");
    }

    @Override
    public void onDisable() {
        if (portals != null) {
            portals.shutdown();
        }
        if (exitPortals != null) {
            exitPortals.shutdown();
        }
        if (boss != null) {
            boss.shutdown();
        }
        if (discRecipeKey != null) {
            Bukkit.removeRecipe(discRecipeKey);
        }
        getServer().getScheduler().cancelTasks(this);
    }

    @Override
    public ChunkGenerator getDefaultWorldGenerator(String worldName, String id) {
        return new CandyChunkGenerator(getConfig().getLong("candy-world.seed", 20260607L));
    }

    private void registerDiscRecipe() {
        discRecipeKey = new NamespacedKey(this, "candy_disc");
        Bukkit.removeRecipe(discRecipeKey);
        ShapedRecipe recipe = new ShapedRecipe(discRecipeKey, items.disc());
        recipe.shape("CNC", "DGD", "CNC");
        recipe.setIngredient('C', new RecipeChoice.ExactChoice(items.shard(1)));
        recipe.setIngredient('N', Material.NETHERITE_INGOT);
        recipe.setIngredient('D', Material.DIAMOND);
        recipe.setIngredient('G', Material.GOLD_INGOT);
        Bukkit.addRecipe(recipe);
    }

    /** Short cooldown so a player is not bounced between portals. */
    public boolean tryWarp(UUID id) {
        long now = System.currentTimeMillis();
        Long last = warpCooldown.get(id);
        if (last != null && now - last < 3000L) {
            return false;
        }
        warpCooldown.put(id, now);
        return true;
    }

    public CandyItems items() {
        return items;
    }

    public CandyWorld candyWorld() {
        return candyWorld;
    }

    public ReturnStore returns() {
        return returns;
    }

    public PortalManager portals() {
        return portals;
    }

    public ExitPortalManager exitPortals() {
        return exitPortals;
    }

    public BossManager boss() {
        return boss;
    }
}
