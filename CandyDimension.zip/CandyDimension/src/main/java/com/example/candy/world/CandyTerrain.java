package com.example.candy.world;

import org.bukkit.util.noise.SimplexOctaveGenerator;

import java.util.Random;

/** Deterministic height function, shared by the generator and everything that needs the ground level. */
public final class CandyTerrain {

    private final SimplexOctaveGenerator hills;
    private final SimplexOctaveGenerator detail;

    public CandyTerrain(long seed) {
        hills = new SimplexOctaveGenerator(new Random(seed), 4);
        hills.setScale(1.0 / 120.0);
        detail = new SimplexOctaveGenerator(new Random(seed + 101L), 2);
        detail.setScale(1.0 / 24.0);
    }

    /** Returns the first free Y above the ground (the top log block sits at height - 1). */
    public int height(int x, int z) {
        double h = 72.0
                + hills.noise(x, z, 0.5, 0.5, true) * 14.0
                + detail.noise(x, z, 0.5, 0.5, true) * 2.5;
        double d = Math.sqrt((double) x * x + (double) z * z);
        if (d < 40.0) {
            double t = Math.max(0.0, d - 12.0) / 28.0;
            h = 72.0 + (h - 72.0) * t;
        }
        return Math.max(56, (int) Math.round(h));
    }
}
